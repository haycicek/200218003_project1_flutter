package com.example.Notes

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
